// host.jsx
// ExtendScript "backend" panelu Snap. Funkcje wywolywane z index.html/js/main.js
// przez window.__adobe_cep__.evalScript("nazwaFunkcji()").

function getComp() {
    var comp = app.project.activeItem;
    if (!(comp && comp instanceof CompItem)) {
        alert("Zaznacz najpierw kompozycje.");
        return null;
    }
    return comp;
}

function getSelectedLayer(comp) {
    if (comp.selectedLayers.length === 0) return null;
    return comp.selectedLayers[0];
}

// Bounding box zaznaczonej warstwy w przestrzeni kompozycji, liczony recznie
// (bez layer.toComp() - w niektorych wersjach AE ta metoda jest niedostepna).
function getLayerBoundsInComp(comp, layer) {
    var r = layer.sourceRectAtTime(comp.time, false);
    var corners = [
        [r.left, r.top],
        [r.left + r.width, r.top],
        [r.left + r.width, r.top + r.height],
        [r.left, r.top + r.height]
    ];

    var pos = layer.transform.position.value;
    var anchor = layer.transform.anchorPoint.value;
    var scale = layer.transform.scale.value;
    var rotation = 0;
    try { rotation = layer.transform.rotation.value; } catch (e) { rotation = 0; }

    var rad = rotation * Math.PI / 180;
    var cosR = Math.cos(rad), sinR = Math.sin(rad);
    var sx = scale[0] / 100, sy = scale[1] / 100;

    var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (var i = 0; i < corners.length; i++) {
        var dx = (corners[i][0] - anchor[0]) * sx;
        var dy = (corners[i][1] - anchor[1]) * sy;
        var rx = dx * cosR - dy * sinR;
        var ry = dx * sinR + dy * cosR;
        var px = pos[0] + rx;
        var py = pos[1] + ry;
        if (px < minX) minX = px;
        if (px > maxX) maxX = px;
        if (py < minY) minY = py;
        if (py > maxY) maxY = py;
    }

    return {
        left: minX, top: minY,
        width: Math.max(4, Math.round(maxX - minX)),
        height: Math.max(4, Math.round(maxY - minY)),
        centerX: (minX + maxX) / 2,
        centerY: (minY + maxY) / 2
    };
}

function addSolidLike(isAdjustment) {
    var comp = getComp();
    if (!comp) return;
    app.beginUndoGroup(isAdjustment ? "Adjustment Layer" : "Solid");
    try {
        var srcLayer = getSelectedLayer(comp);
        var w = comp.width, h = comp.height, cx = comp.width / 2, cy = comp.height / 2;
        if (srcLayer) {
            var b = getLayerBoundsInComp(comp, srcLayer);
            w = b.width; h = b.height; cx = b.centerX; cy = b.centerY;
        }
        var color = isAdjustment ? [1, 1, 1] : [0.5, 0.5, 0.5];
        var name = isAdjustment ? "Adjustment Layer" : "Solid";
        var newLayer = comp.layers.addSolid(color, name, w, h, comp.pixelAspect, comp.duration);
        if (isAdjustment) newLayer.adjustmentLayer = true;
        newLayer.property("Position").setValue([cx, cy]);
        if (srcLayer) {
            newLayer.moveBefore(srcLayer);
            newLayer.startTime = srcLayer.startTime;
            newLayer.inPoint = srcLayer.inPoint;
            newLayer.outPoint = srcLayer.outPoint;
        }
    } catch (e) { alert("Blad: " + e.toString()); }
    app.endUndoGroup();
}

function addText() {
    var comp = getComp();
    if (!comp) return;
    app.beginUndoGroup("Text Layer");
    try { comp.layers.addText("Text"); }
    catch (e) { alert("Blad: " + e.toString()); }
    app.endUndoGroup();
}

function addShape() {
    var comp = getComp();
    if (!comp) return;
    app.beginUndoGroup("Shape Layer");
    try { comp.layers.addShape(); }
    catch (e) { alert("Blad: " + e.toString()); }
    app.endUndoGroup();
}

function addLight() {
    var comp = getComp();
    if (!comp) return;
    app.beginUndoGroup("Light");
    try { comp.layers.addLight("Light", [comp.width / 2, comp.height / 2]); }
    catch (e) { alert("Blad: " + e.toString()); }
    app.endUndoGroup();
}

function addCamera() {
    var comp = getComp();
    if (!comp) return;
    app.beginUndoGroup("Camera");
    try { comp.layers.addCamera("Camera", [comp.width / 2, comp.height / 2]); }
    catch (e) { alert("Blad: " + e.toString()); }
    app.endUndoGroup();
}

function addNull() {
    var comp = getComp();
    if (!comp) return;
    app.beginUndoGroup("Null Object");
    try { comp.layers.addNull(comp.duration); }
    catch (e) { alert("Blad: " + e.toString()); }
    app.endUndoGroup();
}

function newCompOrPrecompose() {
    var comp = getComp();
    if (!comp) return;
    app.beginUndoGroup("Composition");
    try {
        if (comp.selectedLayers.length > 0) {
            var idx = [];
            for (var i = 0; i < comp.selectedLayers.length; i++) idx.push(comp.selectedLayers[i].index);
            comp.layers.precompose(idx, "Precomp", true);
        } else {
            app.project.items.addComp("New Comp", comp.width, comp.height, comp.pixelAspect, comp.duration, comp.frameRate);
        }
    } catch (e) { alert("Blad: " + e.toString()); }
    app.endUndoGroup();
}

function duplicateLayer() {
    var comp = getComp();
    if (!comp) return;
    app.beginUndoGroup("Duplicate");
    try {
        for (var i = 0; i < comp.selectedLayers.length; i++) comp.selectedLayers[i].duplicate();
    } catch (e) { alert("Blad: " + e.toString()); }
    app.endUndoGroup();
}

function splitLayer() {
    var comp = getComp();
    if (!comp) return;
    app.beginUndoGroup("Split Layer");
    try {
        var t = comp.time;
        for (var i = 0; i < comp.selectedLayers.length; i++) {
            var layer = comp.selectedLayers[i];
            if (t <= layer.inPoint || t >= layer.outPoint) continue;
            var dup = layer.duplicate();
            dup.inPoint = t;
            layer.outPoint = t;
        }
    } catch (e) { alert("Blad: " + e.toString()); }
    app.endUndoGroup();
}

function trimIn() {
    var comp = getComp();
    if (!comp) return;
    app.beginUndoGroup("Trim In");
    try {
        for (var i = 0; i < comp.selectedLayers.length; i++) comp.selectedLayers[i].inPoint = comp.time;
    } catch (e) { alert("Blad: " + e.toString()); }
    app.endUndoGroup();
}

function trimOut() {
    var comp = getComp();
    if (!comp) return;
    app.beginUndoGroup("Trim Out");
    try {
        for (var i = 0; i < comp.selectedLayers.length; i++) comp.selectedLayers[i].outPoint = comp.time;
    } catch (e) { alert("Blad: " + e.toString()); }
    app.endUndoGroup();
}
